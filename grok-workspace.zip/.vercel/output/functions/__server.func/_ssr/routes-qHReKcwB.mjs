import { i as __toESM, n as __exportAll } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Play, d as Hand, f as Crosshair, g as Bomb, h as Box, i as User, l as Pause, m as Car, n as VolumeX, o as Sun, p as Circle, r as Volume2, s as RotateCcw, t as Zap, u as Moon } from "../_libs/lucide-react.mjs";
import { a as Material, c as RaycastResult, d as Vec3, f as World, i as Cylinder, l as SAPBroadphase, n as Box$1, o as Plane, r as ContactMaterial, s as PointToPointConstraint, t as Body, u as Sphere } from "../_libs/cannon-es.mjs";
import { C as SphereGeometry, S as Scene, T as Vector3, _ as Object3D, a as Color, b as RepeatWrapping, c as DynamicDrawUsage, d as HemisphereLight, f as InstancedMesh, g as MeshLambertMaterial, h as MeshBasicMaterial, i as CanvasTexture, l as Fog, m as Mesh, n as AmbientLight, o as CylinderGeometry, p as LinearFilter, r as BoxGeometry, s as DirectionalLight, t as WebGLRenderer, u as Group, v as PerspectiveCamera, w as SpotLight, x as SRGBColorSpace, y as PlaneGeometry } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-qHReKcwB.js
var routes_qHReKcwB_exports = /* @__PURE__ */ __exportAll({
	component: () => Home,
	n: () => YardSim,
	t: () => WEAPON_SLOTS
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WEAPON_SLOTS = [
	{
		name: "Пистолет",
		short: "ПМ",
		kind: "gun",
		mag: 12,
		reserve: 72,
		cooldown: .2,
		reload: 1.05,
		auto: false,
		dmg: 28,
		force: 5,
		range: 70,
		spread: .012,
		pellets: 1,
		recoil: .02,
		shake: .12
	},
	{
		name: "Дробовик",
		short: "Дробь",
		kind: "gun",
		mag: 6,
		reserve: 30,
		cooldown: .72,
		reload: 1.5,
		auto: false,
		dmg: 12,
		force: 3.2,
		range: 26,
		spread: .09,
		pellets: 8,
		recoil: .045,
		shake: .32
	},
	{
		name: "Автомат",
		short: "Авто",
		kind: "gun",
		mag: 30,
		reserve: 120,
		cooldown: .09,
		reload: 1.35,
		auto: true,
		dmg: 15,
		force: 2.4,
		range: 80,
		spread: .022,
		pellets: 1,
		recoil: .012,
		shake: .07
	},
	{
		name: "Клешня",
		short: "Клешня",
		kind: "claw",
		mag: 0,
		reserve: 0,
		cooldown: .1,
		reload: 0,
		auto: false,
		dmg: 0,
		force: 0,
		range: 6,
		spread: 0,
		pellets: 1,
		recoil: 0,
		shake: 0
	},
	{
		name: "Граната",
		short: "Граната",
		kind: "nade",
		mag: 1,
		reserve: 6,
		cooldown: .7,
		reload: .4,
		auto: false,
		dmg: 0,
		force: 0,
		range: 0,
		spread: 0,
		pellets: 1,
		recoil: 0,
		shake: .08
	},
	{
		name: "Лом",
		short: "Лом",
		kind: "melee",
		mag: 0,
		reserve: 0,
		cooldown: .42,
		reload: 0,
		auto: false,
		dmg: 46,
		force: 9,
		range: 2.3,
		spread: 0,
		pellets: 1,
		recoil: 0,
		shake: .12
	}
];
var EYE = 1.62;
var PR = .36;
var clamp = (v, a, b) => Math.max(a, Math.min(b, v));
var TIMES = {
	day: {
		top: "#7eb0e0",
		mid: "#d5e6f5",
		fog: "#c5d4e2",
		sun: "#fff4d2",
		sunI: 2.35,
		hemi: "#c5ddf5",
		ground: "#6a5a48",
		hemiI: .85,
		exp: 1.02,
		sx: 30,
		sy: 48,
		sz: 12
	},
	dusk: {
		top: "#1b2440",
		mid: "#e39a62",
		fog: "#c47a52",
		sun: "#ffb067",
		sunI: 1.75,
		hemi: "#f0a06a",
		ground: "#2a211c",
		hemiI: .62,
		exp: 1.06,
		sx: 48,
		sy: 16,
		sz: 18
	},
	night: {
		top: "#070910",
		mid: "#1c2744",
		fog: "#101622",
		sun: "#9bb4ff",
		sunI: .28,
		hemi: "#243056",
		ground: "#120e0c",
		hemiI: .38,
		exp: 1.18,
		sx: -20,
		sy: 24,
		sz: -30
	}
};
var Sfx = class {
	ctx = null;
	master = null;
	bus = null;
	buffers = {};
	muted = false;
	unlock() {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return;
		if (!this.ctx) {
			this.ctx = new AC();
			this.master = this.ctx.createGain();
			this.bus = this.ctx.createGain();
			this.bus.connect(this.master);
			this.master.connect(this.ctx.destination);
			this.master.gain.value = .85;
			this.buffers.shot = this.noise(.09, .55);
			this.buffers.boom = this.noise(.48, .12);
			this.buffers.thud = this.noise(.14, .18);
			this.buffers.swing = this.noise(.09, .7);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	noise(seconds, bright) {
		const rate = this.ctx.sampleRate;
		const n = Math.floor(rate * seconds);
		const buf = this.ctx.createBuffer(1, n, rate);
		const data = buf.getChannelData(0);
		let last = 0;
		for (let i = 0; i < n; i++) {
			const white = Math.random() * 2 - 1;
			last = last * (1 - bright) + white * bright;
			data[i] = last * (1 - i / n) ** 1.5;
		}
		return buf;
	}
	play(name, rate = 1, gain = .3) {
		if (!this.ctx || !this.bus || this.muted) return;
		const buffer = this.buffers[name];
		if (!buffer) return;
		const src = this.ctx.createBufferSource();
		const g = this.ctx.createGain();
		src.buffer = buffer;
		src.playbackRate.value = rate;
		g.gain.value = gain;
		src.connect(g);
		g.connect(this.bus);
		src.start();
		src.onended = () => {
			src.disconnect();
			g.disconnect();
		};
	}
	tone(freq, dur, gain, type = "sine") {
		if (!this.ctx || !this.bus || this.muted) return;
		const o = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		o.type = type;
		o.frequency.value = freq;
		const t = this.ctx.currentTime;
		g.gain.setValueAtTime(gain, t);
		g.gain.exponentialRampToValueAtTime(.001, t + dur);
		o.connect(g);
		g.connect(this.bus);
		o.start(t);
		o.stop(t + dur);
		o.onended = () => {
			o.disconnect();
			g.disconnect();
		};
	}
};
var YardSim = class {
	canvas;
	onHud = null;
	touch = {
		moveX: 0,
		moveY: 0,
		fire: false,
		jump: false,
		use: false
	};
	renderer;
	scene;
	camera;
	viewCam;
	world;
	rayFrom = new Vec3();
	rayTo = new Vec3();
	rayResult = new RaycastResult();
	imp = new Vec3();
	rel = new Vec3();
	lookDir = new Vector3();
	rightDir = new Vector3();
	upDir = new Vector3();
	aim = new Vector3();
	groundMat;
	propMat;
	bouncyMat;
	boxGeo;
	sphereGeo;
	cylGeo;
	mats = /* @__PURE__ */ new Map();
	statics = [];
	dyns = [];
	bots = [];
	bodyMeta = /* @__PURE__ */ new Map();
	gun = new Group();
	muzzleMesh = null;
	muzzleMat;
	sky;
	skyCtx;
	skyTex;
	fog;
	sun;
	hemi;
	sunMesh;
	flash;
	carMesh;
	wheels = [];
	sparkMesh;
	sparkLife = /* @__PURE__ */ new Float32Array(72);
	sparkPos = /* @__PURE__ */ new Float32Array(216);
	sparkVel = /* @__PURE__ */ new Float32Array(216);
	sparkCursor = 0;
	sparkDummy = new Object3D();
	sparkColor = new Color();
	tracers = [];
	tracerCursor = 0;
	sfx = new Sfx();
	keys = /* @__PURE__ */ new Set();
	injected = /* @__PURE__ */ new Set();
	steerOverride = null;
	raf = 0;
	last = 0;
	acc = 0;
	dead = false;
	ro = null;
	coarse = false;
	reduced = false;
	playing = false;
	paused = false;
	mode = "sandbox";
	timeName = "dusk";
	hostile = false;
	slow = false;
	lampOn = false;
	weapon = 0;
	mag = WEAPON_SLOTS.map((w) => w.mag);
	reserve = WEAPON_SLOTS.map((w) => w.reserve);
	px = 0;
	py = EYE;
	pz = 18;
	yaw = 0;
	pitch = -.12;
	vx = 0;
	vy = 0;
	vz = 0;
	grounded = true;
	wasVy = 0;
	walk = 0;
	hp = 100;
	invuln = 0;
	sinceHurt = 10;
	downT = 0;
	hurt = 0;
	shake = 0;
	kick = 0;
	gunKick = 0;
	bloom = 0;
	muzzleT = 0;
	hitMark = 0;
	cool = 0;
	reloading = 0;
	ads = false;
	driving = false;
	wasDriving = false;
	boosting = false;
	held = null;
	fireHeld = false;
	firePressed = false;
	fireLatch = false;
	altPressed = false;
	altLatch = false;
	jumpLatch = false;
	useLatch = false;
	lookDx = 0;
	lookDy = 0;
	lastLookDx = 0;
	sway = 0;
	camX = 0;
	camY = 8;
	camZ = 20;
	orbit = .4;
	time = 0;
	hitStop = 0;
	wave = 1;
	waveLeft = 0;
	waveDelay = 0;
	spawnTimer = .3;
	kills = 0;
	chaos = 0;
	bestWave = 0;
	bestChaos = 0;
	hint = "";
	hintT = 0;
	lastEmit = 0;
	botSeq = 0;
	wheelSpin = 0;
	car = {
		x: 6,
		z: 11,
		yaw: 0,
		speed: 0,
		hp: 140,
		deadT: 0
	};
	mouseFire = false;
	mouseAlt = false;
	onKeyDown = (e) => {
		if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
		this.keys.add(e.code);
		if (e.repeat) return;
		if (e.code === "Escape") {
			this.togglePause();
			return;
		}
		if (!this.playing || this.paused) return;
		if (e.code === "KeyF") this.tryUse();
		if (e.code === "KeyE" && this.held) this.releaseHeld(true);
		if (e.code === "KeyR") this.startReload();
		if (e.code === "KeyC") this.toggleSlow();
		if (e.code === "KeyN") this.cycleTime();
		if (e.code === "KeyX") this.deleteLook();
		if (e.code === "KeyL") {
			this.lampOn = !this.lampOn;
			this.flash.intensity = this.lampOn ? 18 : 0;
			this.emitNow();
		}
		if (e.code.startsWith("Digit")) {
			const n = Number(e.code.slice(5));
			if (n >= 1 && n <= 6) this.setWeapon(n - 1);
		}
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
	};
	onBlur = () => {
		this.keys.clear();
		this.mouseFire = false;
		this.mouseAlt = false;
	};
	onPointerDown = (e) => {
		if (this.coarse || !this.playing || this.paused) return;
		if (document.pointerLockElement !== this.canvas) {
			this.requestLock();
			return;
		}
		if (e.button === 0) this.mouseFire = true;
		if (e.button === 2) this.mouseAlt = true;
	};
	onPointerUp = (e) => {
		if (e.button === 0) this.mouseFire = false;
		if (e.button === 2) this.mouseAlt = false;
	};
	onMouseMove = (e) => {
		if (document.pointerLockElement !== this.canvas) return;
		this.lookDx += e.movementX;
		this.lookDy += e.movementY;
	};
	onWheel = (e) => {
		e.preventDefault();
		if (!this.playing || this.paused) return;
		this.setWeapon(this.weapon + (e.deltaY > 0 ? 1 : -1));
	};
	onMenu = (e) => e.preventDefault();
	onVis = () => {
		if (document.visibilityState === "visible") this.sfx.unlock();
	};
	mount(canvas, onHud, touch) {
		this.canvas = canvas;
		this.onHud = onHud;
		this.touch = touch;
		this.coarse = window.matchMedia("(pointer: coarse)").matches;
		this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.loadBest();
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.setClearColor("#100e0c", 1);
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.scene = new Scene();
		this.camera = new PerspectiveCamera(76, 1, .08, 240);
		this.camera.rotation.order = "YXZ";
		this.viewCam = new PerspectiveCamera(76, 1, .05, 10);
		this.viewCam.layers.set(1);
		this.scene.add(this.camera);
		this.boxGeo = new BoxGeometry(1, 1, 1);
		this.sphereGeo = new SphereGeometry(1, 14, 10);
		this.cylGeo = new CylinderGeometry(1, 1, 1, 12);
		this.muzzleMat = new MeshBasicMaterial({ color: "#ffe6c2" });
		this.world = new World({ gravity: new Vec3(0, -24, 0) });
		this.world.broadphase = new SAPBroadphase(this.world);
		this.world.allowSleep = true;
		const solver = this.world.solver;
		solver.iterations = 12;
		this.groundMat = new Material("ground");
		this.propMat = new Material("prop");
		this.bouncyMat = new Material("bouncy");
		this.world.addContactMaterial(new ContactMaterial(this.groundMat, this.propMat, {
			friction: .42,
			restitution: .08
		}));
		this.world.addContactMaterial(new ContactMaterial(this.groundMat, this.bouncyMat, {
			friction: .2,
			restitution: .86
		}));
		this.world.addContactMaterial(new ContactMaterial(this.propMat, this.propMat, {
			friction: .35,
			restitution: .12
		}));
		this.world.defaultContactMaterial.friction = .3;
		const ground = new Body({
			mass: 0,
			material: this.groundMat
		});
		ground.addShape(new Plane());
		ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
		this.world.addBody(ground);
		this.buildLights();
		this.buildMap();
		this.buildCar();
		this.dressProps();
		this.dressBots();
		this.initFx();
		this.scene.add(this.gun);
		this.rebuildGun();
		this.applyTime();
		this.bind();
		this.resize();
		this.ro = new ResizeObserver(() => this.resize());
		this.ro.observe(canvas);
		this.hookControls();
		this.last = performance.now();
		this.emitNow();
		this.raf = requestAnimationFrame(this.frame);
	}
	dispose() {
		this.dead = true;
		cancelAnimationFrame(this.raf);
		this.ro?.disconnect();
		this.unbind();
		this.boxGeo?.dispose();
		this.sphereGeo?.dispose();
		this.cylGeo?.dispose();
		this.muzzleMat?.dispose();
		this.skyTex?.dispose();
		this.mats.forEach((m) => m.dispose());
		this.renderer?.dispose();
		if (window.__controlsTest) delete window.__controlsTest;
	}
	unlock() {
		this.sfx.unlock();
	}
	addLook(dx, dy) {
		if (!this.playing || this.paused || this.driving) return;
		this.lookDx += dx;
		this.lookDy += dy;
	}
	begin(mode) {
		this.mode = mode;
		this.playing = true;
		this.paused = false;
		this.driving = false;
		this.wasDriving = false;
		this.downT = 0;
		this.hp = 100;
		this.kills = 0;
		this.chaos = 0;
		this.wave = 1;
		this.waveLeft = mode === "arena" ? 3 : 0;
		this.waveDelay = mode === "arena" ? .6 : 0;
		this.spawnTimer = .4;
		this.hostile = mode === "arena";
		this.px = 0;
		this.py = EYE;
		this.pz = 18;
		this.yaw = 0;
		this.pitch = -.08;
		this.vx = 0;
		this.vy = 0;
		this.vz = 0;
		this.held = null;
		this.clearBots();
		this.clearDynamics();
		this.dressProps();
		if (mode === "sandbox") this.dressBots();
		this.mag = WEAPON_SLOTS.map((w) => w.mag);
		this.reserve = WEAPON_SLOTS.map((w) => mode === "sandbox" && (w.kind === "gun" || w.kind === "nade") ? 999 : w.reserve);
		this.car.x = 6;
		this.car.z = 11;
		this.car.yaw = 0;
		this.car.speed = 0;
		this.car.hp = 140;
		this.car.deadT = 0;
		this.hint = mode === "arena" ? "Волна 1" : "Ломай всё";
		this.hintT = 2.4;
		this.unlock();
		this.requestLock();
		this.emitNow();
	}
	enterCar() {
		if (!this.playing) this.begin("sandbox");
		if (this.car.deadT > 0) {
			this.car.deadT = 0;
			this.car.hp = 140;
		}
		this.driving = true;
		this.wasDriving = false;
		this.downT = 0;
		this.paused = false;
	}
	togglePause() {
		if (!this.playing) return;
		this.paused = !this.paused;
		if (!this.paused) this.requestLock();
		this.saveBest();
		this.emitNow();
	}
	setWeapon(i) {
		const n = WEAPON_SLOTS.length;
		this.weapon = (i % n + n) % n;
		this.reloading = 0;
		this.rebuildGun();
		this.emitNow();
	}
	spawnKind(kind) {
		if (!this.playing || this.paused) return;
		const yaw = this.driving ? this.car.yaw : this.yaw;
		const fx = -Math.sin(yaw);
		const fz = -Math.cos(yaw);
		const x = (this.driving ? this.car.x : this.px) + fx * 3.4;
		const z = (this.driving ? this.car.z : this.pz) + fz * 3.4;
		if (kind === "bot") {
			this.spawnBot(x, z, this.mode === "arena" ? true : this.hostile);
			this.emitNow();
			return;
		}
		const specs = {
			barrel: {
				kind: "barrel",
				x,
				y: 2.2,
				z,
				w: .72,
				h: 1,
				d: .72,
				mass: 8,
				color: "#3d4550",
				hp: 50,
				cyl: true
			},
			explosive: {
				kind: "explosive",
				x,
				y: 2.3,
				z,
				w: .74,
				h: 1.05,
				d: .74,
				mass: 9,
				color: "#9e1b2d",
				emissive: "#d7263d",
				hp: 22,
				cyl: true
			},
			crate: {
				kind: "crate",
				x,
				y: 2,
				z,
				w: .8,
				h: .8,
				d: .8,
				mass: 6,
				color: "#8a5a32",
				hp: 40
			},
			ball: {
				kind: "ball",
				x,
				y: 2.2,
				z,
				w: 1.15,
				h: 1,
				d: 1,
				mass: 3.5,
				color: "#e25b1a",
				hp: 80,
				sphere: true,
				bouncy: true
			},
			block: {
				kind: "block",
				x,
				y: 2.2,
				z,
				w: 1.1,
				h: .7,
				d: .7,
				mass: 16,
				color: "#6e675f",
				hp: 110
			}
		};
		this.makeDyn(specs[kind]);
		this.trim();
		this.emitNow();
	}
	toggleHostile() {
		if (this.mode === "arena") return;
		this.hostile = !this.hostile;
		for (const b of this.bots) b.hostile = this.hostile;
		this.hint = this.hostile ? "Боты злые" : "Боты спокойные";
		this.hintT = 1.2;
		this.emitNow();
	}
	cycleTime() {
		const order = [
			"day",
			"dusk",
			"night"
		];
		this.timeName = order[(order.indexOf(this.timeName) + 1) % 3];
		this.lampOn = this.timeName === "night";
		this.applyTime();
		this.hint = this.timeName === "day" ? "День" : this.timeName === "dusk" ? "Закат" : "Ночь";
		this.hintT = 1.1;
		this.emitNow();
	}
	toggleSlow() {
		this.slow = !this.slow;
		this.hint = this.slow ? "Слоу-мо" : "Обычное время";
		this.hintT = 1;
		this.emitNow();
	}
	toggleMute() {
		this.sfx.muted = !this.sfx.muted;
		try {
			localStorage.setItem("svalka.mute", this.sfx.muted ? "1" : "0");
		} catch {}
		this.emitNow();
	}
	clearMess() {
		if (!this.playing) return;
		this.clearBots();
		this.clearDynamics();
		this.held = null;
		this.dressProps();
		if (this.mode === "sandbox") this.dressBots();
		this.hint = "Двор чист";
		this.hintT = 1.1;
		this.emitNow();
	}
	hookControls() {
		window.__controlsTest = {
			getYaw: () => this.driving ? this.car.yaw : this.yaw,
			getSpeed: () => this.driving ? this.car.speed : Math.hypot(this.vx, this.vz),
			setKeys: (codes) => {
				this.injected = new Set(codes);
			},
			setSteer: (v) => {
				this.steerOverride = v;
			},
			enterCar: () => this.enterCar()
		};
	}
	bind() {
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		window.addEventListener("pointerup", this.onPointerUp);
		this.canvas.addEventListener("pointerdown", this.onPointerDown);
		this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
		this.canvas.addEventListener("contextmenu", this.onMenu);
		document.addEventListener("mousemove", this.onMouseMove);
		document.addEventListener("visibilitychange", this.onVis);
	}
	unbind() {
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		window.removeEventListener("pointerup", this.onPointerUp);
		this.canvas?.removeEventListener("pointerdown", this.onPointerDown);
		this.canvas?.removeEventListener("wheel", this.onWheel);
		this.canvas?.removeEventListener("contextmenu", this.onMenu);
		document.removeEventListener("mousemove", this.onMouseMove);
		document.removeEventListener("visibilitychange", this.onVis);
	}
	requestLock() {
		if (this.coarse || !this.playing || !this.canvas) return;
		try {
			const p = this.canvas.requestPointerLock();
			Promise.resolve(p).catch(() => void 0);
		} catch {}
	}
	down(code) {
		return this.keys.has(code) || this.injected.has(code);
	}
	frame = (now) => {
		if (this.dead) return;
		const dt = Math.min(.05, (now - this.last) / 1e3 || 0);
		this.last = now;
		this.applyLook();
		if (this.hitStop > 0 && this.playing && !this.paused) this.hitStop -= dt;
		else if (!this.paused) {
			const scale = this.playing && this.slow ? .35 : 1;
			this.acc += dt * scale;
			const h = 1 / 60;
			let n = 0;
			while (this.acc >= h && n < 4) {
				this.integrate(h);
				this.world.step(h);
				this.acc -= h;
				n++;
			}
		}
		this.syncMeshes();
		this.updateFx(dt);
		this.updateCamera(dt);
		this.render();
		if (now - this.lastEmit > 90) {
			this.lastEmit = now;
			this.emitNow();
		}
		this.raf = requestAnimationFrame(this.frame);
	};
	applyLook() {
		if (!this.playing || this.paused || this.driving) {
			this.lookDx = 0;
			this.lookDy = 0;
			return;
		}
		const sens = .00215 * (this.ads ? .62 : 1);
		this.yaw -= this.lookDx * sens;
		this.pitch -= this.lookDy * sens;
		this.pitch = clamp(this.pitch, -1.35, 1.35);
		this.sway += (clamp(-this.lookDx * .003, -.12, .12) - this.sway) * .2;
		this.lookDx = 0;
		this.lookDy = 0;
	}
	integrate(dt) {
		this.time += dt;
		this.fireHeld = this.mouseFire || this.touch.fire;
		this.firePressed = this.fireHeld && !this.fireLatch;
		this.fireLatch = this.fireHeld;
		const alt = this.mouseAlt;
		this.altPressed = alt && !this.altLatch;
		this.altLatch = alt;
		const w = WEAPON_SLOTS[this.weapon];
		this.ads = this.playing && !this.driving && w.kind === "gun" && alt;
		if (this.playing && this.downT > 0) {
			this.downT -= dt;
			if (this.downT <= 0) this.respawn();
		}
		if (this.playing && this.downT <= 0) {
			if (this.driving) this.updateCar(dt);
			else this.updatePlayer(dt);
			this.handleCombat(dt);
			if (this.sinceHurt > (this.mode === "sandbox" ? .2 : 3.4)) this.hp = Math.min(100, this.hp + (this.mode === "sandbox" ? 22 : 6) * dt);
		}
		this.updateBots(dt);
		this.updateNades(dt);
		this.updateWaves(dt);
		this.decayCar(dt);
		if (this.invuln > 0) this.invuln -= dt;
		if (this.hintT > 0) this.hintT -= dt;
		this.sinceHurt += dt;
		for (const d of this.dyns.slice()) if (d.body.position.y < -8) this.removeDyn(d);
	}
	updatePlayer(dt) {
		const forwardX = -Math.sin(this.yaw);
		const forwardZ = -Math.cos(this.yaw);
		const rightX = Math.cos(this.yaw);
		const rightZ = -Math.sin(this.yaw);
		let ix = 0;
		let iz = 0;
		if (Math.hypot(this.touch.moveX, this.touch.moveY) > .18) {
			ix = this.touch.moveX;
			iz = this.touch.moveY;
		} else {
			if (this.down("KeyD")) ix += 1;
			if (this.down("KeyA")) ix -= 1;
			if (this.down("KeyW")) iz += 1;
			if (this.down("KeyS")) iz -= 1;
		}
		const len = Math.hypot(ix, iz);
		if (len > 1) {
			ix /= len;
			iz /= len;
		}
		const sp = this.down("ShiftLeft") || this.down("ShiftRight") ? 8.6 : 4.8;
		const wx = rightX * ix + forwardX * iz;
		const wz = rightZ * ix + forwardZ * iz;
		const accel = this.grounded ? 16 : 3.5;
		const blend = 1 - Math.exp(-accel * dt);
		this.vx += (wx * sp - this.vx) * blend;
		this.vz += (wz * sp - this.vz) * blend;
		const jumpDown = this.down("Space") || this.touch.jump;
		if (jumpDown && !this.jumpLatch && this.grounded) this.vy = 7.6;
		this.jumpLatch = jumpDown;
		this.vy -= 24 * dt;
		const feet = this.py - EYE;
		const head = this.py + .18;
		const ox = this.px;
		const oz = this.pz;
		const nx = this.px + this.vx * dt;
		const nz = this.pz + this.vz * dt;
		let sep = this.separate(nx, nz, PR, feet, head, true, false);
		if (Math.hypot(sep.x - nx, sep.z - nz) > .004 && this.grounded) {
			const up = this.separate(nx, nz, PR, feet + .46, head + .46, false, false);
			if (Math.hypot(up.x - ox, up.z - oz) > Math.hypot(sep.x - ox, sep.z - oz) + .02) {
				sep = up;
				this.py += .46;
			}
		}
		if (sep.hitStatic) {
			if (Math.abs(sep.x - ox) < Math.abs(this.vx * dt) * .45) this.vx *= .15;
			if (Math.abs(sep.z - oz) < Math.abs(this.vz * dt) * .45) this.vz *= .15;
		}
		this.px = clamp(sep.x, -34, 34);
		this.pz = clamp(sep.z, -34, 34);
		this.py += this.vy * dt;
		const g = this.groundAt(this.px, this.py, this.pz, this.vy, dt);
		this.py = g.y;
		this.vy = g.vy;
		this.grounded = g.grounded;
		if (this.wasVy < -9 && this.grounded) {
			this.sfx.play("thud", 1.3, .18);
			this.shake = Math.min(1, this.shake + .18);
		}
		this.wasVy = this.vy;
		this.walk += Math.hypot(this.vx, this.vz) * dt;
	}
	updateCar(dt) {
		if (this.car.deadT > 0) return;
		let steer = 0;
		if (this.steerOverride !== null) steer = clamp(this.steerOverride, -1, 1);
		else if (Math.abs(this.touch.moveX) > .18) steer = -this.touch.moveX;
		else {
			if (this.down("KeyA") || this.down("ArrowLeft")) steer += 1;
			if (this.down("KeyD") || this.down("ArrowRight")) steer -= 1;
		}
		let throttle = 0;
		if (this.down("KeyW") || this.down("ArrowUp")) throttle += 1;
		if (this.down("KeyS") || this.down("ArrowDown")) throttle -= 1;
		if (Math.abs(this.touch.moveY) > .18) throttle = this.touch.moveY;
		this.boosting = this.down("ShiftLeft") || this.down("ShiftRight") || this.touch.fire;
		if (this.boosting) throttle += .7;
		throttle = clamp(throttle, -1, 1.45);
		const drag = Math.abs(throttle) < .05 ? 1.7 : .2;
		this.car.speed -= this.car.speed * drag * dt;
		this.car.speed += throttle * 20 * dt;
		this.car.speed = clamp(this.car.speed, -8, this.boosting ? 27 : 17);
		const reverse = this.car.speed >= 0 ? 1 : -1;
		const speedFactor = Math.min(1, Math.abs(this.car.speed) / 7);
		this.car.yaw += steer * 2.3 * Math.max(.45, speedFactor) * reverse * dt;
		const fx = -Math.sin(this.car.yaw);
		const fz = -Math.cos(this.car.yaw);
		const nx = this.car.x + fx * this.car.speed * dt;
		const nz = this.car.z + fz * this.car.speed * dt;
		const hit = this.separate(nx, nz, 1.15, .05, 1.45, true, true);
		if (hit.hitStatic) this.car.speed *= -.16;
		else if (hit.hitDyn) this.car.speed *= .84;
		this.car.x = clamp(hit.x, -33, 33);
		this.car.z = clamp(hit.z, -33, 33);
		this.wheelSpin += this.car.speed * dt * 1.4;
		if (this.boosting && Math.abs(this.car.speed) > 3) this.burst(this.car.x - fx * 1.5, .35, this.car.z - fz * 1.5, "#e25b1a", 1, 3);
	}
	separate(x, z, r, feet, head, affectDyn, ignoreCar) {
		let hitStatic = false;
		let hitDyn = false;
		const solve = (minX, maxX, minY, maxY, minZ, maxZ, body) => {
			if (head < minY || feet > maxY) return;
			const cx = clamp(x, minX, maxX);
			const cz = clamp(z, minZ, maxZ);
			let dx = x - cx;
			let dz = z - cz;
			const d2 = dx * dx + dz * dz;
			if (d2 >= r * r) return;
			let nx = 0;
			let nz = 0;
			let pen = 0;
			if (d2 < 1e-8) {
				const left = x - minX;
				const right = maxX - x;
				const back = z - minZ;
				const front = maxZ - z;
				const m = Math.min(left, right, back, front);
				if (m === left) {
					nx = -1;
					pen = left + r;
				} else if (m === right) {
					nx = 1;
					pen = right + r;
				} else if (m === back) {
					nz = -1;
					pen = back + r;
				} else {
					nz = 1;
					pen = front + r;
				}
			} else {
				const d = Math.sqrt(d2);
				pen = r - d;
				nx = dx / d;
				nz = dz / d;
			}
			x += nx * pen;
			z += nz * pen;
			if (body && affectDyn) {
				hitDyn = true;
				body.wakeUp();
				body.velocity.x += nx * (3.2 + pen * 6);
				body.velocity.z += nz * (3.2 + pen * 6);
				body.velocity.y += .35;
			} else if (!body) hitStatic = true;
		};
		for (const s of this.statics) solve(s.minX, s.maxX, s.minY, s.maxY, s.minZ, s.maxZ, null);
		for (const d of this.dyns) {
			if (d.removed || d.body === this.held || d.body.mass <= 0) continue;
			d.body.updateAABB();
			const lo = d.body.aabb.lowerBound;
			const hi = d.body.aabb.upperBound;
			solve(lo.x, hi.x, lo.y, hi.y, lo.z, hi.z, d.body);
		}
		if (!ignoreCar && this.car.deadT <= 0) solve(this.car.x - 1.2, this.car.x + 1.2, 0, 1.25, this.car.z - 1.35, this.car.z + 1.35, null);
		return {
			x,
			z,
			hitStatic,
			hitDyn
		};
	}
	groundAt(x, y, z, vy, dt) {
		const prevFeet = y - EYE - vy * dt;
		const feet = y - EYE;
		let best = -Infinity;
		let landed = false;
		const consider = (minX, maxX, maxY, minZ, maxZ) => {
			if (x + PR < minX || x - PR > maxX || z + PR < minZ || z - PR > maxZ) return;
			if (vy <= 0 && prevFeet >= maxY - .1 && feet <= maxY + .25 && maxY > best) {
				best = maxY;
				landed = true;
			}
		};
		for (const s of this.statics) consider(s.minX, s.maxX, s.maxY, s.minZ, s.maxZ);
		for (const d of this.dyns) {
			if (d.removed || d.body === this.held) continue;
			d.body.updateAABB();
			const lo = d.body.aabb.lowerBound;
			const hi = d.body.aabb.upperBound;
			consider(lo.x, hi.x, hi.y, lo.z, hi.z);
		}
		if (!this.driving && this.car.deadT <= 0) consider(this.car.x - 1.2, this.car.x + 1.2, 1.2, this.car.z - 1.3, this.car.z + 1.3);
		if (landed) return {
			y: best + EYE,
			vy: 0,
			grounded: true
		};
		if (vy <= 0 && prevFeet >= -.05 && feet <= .25) return {
			y: EYE,
			vy: 0,
			grounded: true
		};
		return {
			y,
			vy,
			grounded: false
		};
	}
	handleCombat(dt) {
		if (this.reloading > 0) {
			this.reloading -= dt;
			if (this.reloading <= 0) {
				this.reloading = 0;
				this.finishReload();
			}
		}
		this.cool = Math.max(0, this.cool - dt);
		const w = WEAPON_SLOTS[this.weapon];
		if (this.altPressed && w.kind === "claw") this.pinLook();
		if (w.kind === "claw") this.updateClaw();
		else if (this.held) this.releaseHeld(false);
		if (w.kind === "gun" && (w.auto ? this.fireHeld : this.firePressed)) this.shootGun();
		if (w.kind === "melee" && this.firePressed) this.melee();
		if (w.kind === "nade" && this.firePressed) this.throwNade();
		const use = this.touch.use;
		if (use && !this.useLatch) this.tryUse();
		this.useLatch = use;
	}
	shootGun() {
		const w = WEAPON_SLOTS[this.weapon];
		if (w.kind !== "gun" || this.reloading > 0 || this.cool > 0) return;
		if (this.mag[this.weapon] <= 0) {
			this.startReload();
			this.sfx.tone(140, .04, .05, "square");
			return;
		}
		this.cool = w.cooldown;
		this.mag[this.weapon] = (this.mag[this.weapon] ?? 0) - 1;
		this.kick += w.recoil;
		this.gunKick = .08;
		this.shake = Math.min(1, this.shake + w.shake);
		this.bloom = Math.min(1, this.bloom + (w.pellets > 1 ? .4 : .16));
		this.muzzleT = .05;
		this.sfx.play("shot", .75 + Math.random() * .5, w.pellets > 1 ? .42 : .26);
		this.camera.updateMatrixWorld();
		this.camera.getWorldDirection(this.lookDir);
		this.rightDir.set(1, 0, 0).applyQuaternion(this.camera.quaternion);
		this.upDir.set(0, 1, 0).applyQuaternion(this.camera.quaternion);
		const fx = this.lookDir.x;
		const fy = this.lookDir.y;
		const fz = this.lookDir.z;
		const rxx = this.rightDir.x;
		const rxy = this.rightDir.y;
		const rxz = this.rightDir.z;
		const uxx = this.upDir.x;
		const uxy = this.upDir.y;
		const uxz = this.upDir.z;
		const ox = this.camera.position.x;
		const oy = this.camera.position.y;
		const oz = this.camera.position.z;
		const spread = w.spread + this.bloom * .05;
		for (let p = 0; p < w.pellets; p++) {
			const jx = (Math.random() - .5) * 2 * spread;
			const jy = (Math.random() - .5) * 2 * spread;
			let dx = fx + rxx * jx + uxx * jy;
			let dy = fy + rxy * jx + uxy * jy;
			let dz = fz + rxz * jx + uxz * jy;
			const mag = Math.hypot(dx, dy, dz) || 1;
			dx /= mag;
			dy /= mag;
			dz /= mag;
			this.fireRay(ox, oy, oz, dx, dy, dz, w.range, w.dmg, w.force);
		}
		if ((this.mag[this.weapon] ?? 0) <= 0) this.startReload();
	}
	fireRay(ox, oy, oz, dx, dy, dz, range, dmg, force) {
		const hit = this.ray(ox, oy, oz, ox + dx * range, oy + dy * range, oz + dz * range);
		const ex = hit ? hit.x : ox + dx * range;
		const ey = hit ? hit.y : oy + dy * range;
		const ez = hit ? hit.z : oz + dz * range;
		this.tracer(ox, oy, oz, ex, ey, ez);
		this.aim.set(dx, dy, dz);
		if (!hit?.body) {
			this.burst(ex, ey, ez, "#f3eadf", 3, 2);
			return;
		}
		const meta = this.bodyMeta.get(hit.body);
		if (meta?.bot) this.hurtBot(meta.bot, dmg, dx, dy, dz, force);
		else if (meta?.dyn) this.damageDyn(meta.dyn, dmg, this.aim, force, hit.x, hit.y, hit.z, false);
		this.burst(hit.x, hit.y, hit.z, meta?.bot ? "#d7263d" : "#ffb067", 7, 4.5);
		if (meta?.bot || meta?.dyn) this.hitMark = 1;
	}
	melee() {
		if (this.cool > 0 || this.driving) return;
		this.cool = .42;
		this.gunKick = .06;
		this.shake = Math.min(1, this.shake + .12);
		this.sfx.play("swing", .9 + Math.random() * .3, .22);
		this.camera.updateMatrixWorld();
		this.camera.getWorldDirection(this.lookDir);
		const ox = this.camera.position.x;
		const oy = this.camera.position.y;
		const oz = this.camera.position.z;
		for (const b of this.bots.slice()) {
			const dx = b.x - ox;
			const dy = 1.15 - oy;
			const dz = b.z - oz;
			const dist = Math.hypot(dx, dy, dz);
			if (dist < 2.35 && dx * this.lookDir.x + dy * this.lookDir.y + dz * this.lookDir.z > .35) {
				this.hurtBot(b, 48, dx / (dist || 1), .35, dz / (dist || 1), 9);
				this.hitMark = 1;
			}
		}
		let best = null;
		let bestD = 2.4;
		for (const d of this.dyns) {
			if (d.removed || d.body === this.held) continue;
			const dx = d.body.position.x - ox;
			const dy = d.body.position.y - oy;
			const dz = d.body.position.z - oz;
			const dist = Math.hypot(dx, dy, dz);
			const dot = dx * this.lookDir.x + dy * this.lookDir.y + dz * this.lookDir.z;
			if (dist < bestD && dot > .3) {
				best = d;
				bestD = dist;
			}
		}
		if (best) {
			this.aim.set(this.lookDir.x, this.lookDir.y + .3, this.lookDir.z);
			this.damageDyn(best, 44, this.aim, 11, best.body.position.x, best.body.position.y, best.body.position.z, false);
			this.hitMark = 1;
			this.sfx.play("thud", .7, .28);
		}
	}
	throwNade() {
		if (this.cool > 0 || this.driving) return;
		const i = this.weapon;
		const stock = (this.mag[i] ?? 0) + (this.mode === "sandbox" ? 1 : this.reserve[i] ?? 0);
		if (this.mode === "arena" && stock <= 0) {
			this.sfx.tone(130, .04, .05, "square");
			return;
		}
		this.cool = .65;
		if (this.mode === "arena") {
			if ((this.mag[i] ?? 0) > 0) this.mag[i] = (this.mag[i] ?? 0) - 1;
			else this.reserve[i] = (this.reserve[i] ?? 0) - 1;
		}
		this.camera.updateMatrixWorld();
		this.camera.getWorldDirection(this.lookDir);
		const o = this.camera.position;
		this.makeDyn({
			kind: "nade",
			x: o.x + this.lookDir.x * .7,
			y: o.y + this.lookDir.y * .7 - .15,
			z: o.z + this.lookDir.z * .7,
			w: .28,
			h: .28,
			d: .28,
			mass: 1.1,
			color: "#3d4550",
			hp: 10,
			sphere: true,
			fuse: 1.65
		}).body.velocity.set(this.lookDir.x * 13 + this.vx, this.lookDir.y * 13 + 2.4, this.lookDir.z * 13 + this.vz);
		this.gunKick = .05;
	}
	updateClaw() {
		if (this.held) {
			if (!this.fireHeld) this.releaseHeld(false);
			else this.pullHeld();
			return;
		}
		if (this.firePressed) this.tryGrab();
	}
	tryGrab() {
		const hit = this.lookHit(6.5);
		const dyn = hit?.body ? this.bodyMeta.get(hit.body)?.dyn : void 0;
		if (!dyn || dyn.removed || dyn.body.mass <= 0) return;
		this.held = dyn.body;
		this.held.collisionFilterGroup = 2;
		this.held.wakeUp();
		this.sfx.tone(240, .05, .05, "square");
	}
	pullHeld() {
		const b = this.held;
		if (!b) return;
		this.camera.updateMatrixWorld();
		this.camera.getWorldDirection(this.lookDir);
		const tx = this.camera.position.x + this.lookDir.x * 2.8;
		const ty = this.camera.position.y + this.lookDir.y * 2.8;
		const tz = this.camera.position.z + this.lookDir.z * 2.8;
		b.wakeUp();
		b.velocity.x = (tx - b.position.x) * 12;
		b.velocity.y = (ty - b.position.y) * 12;
		b.velocity.z = (tz - b.position.z) * 12;
		b.angularVelocity.scale(.86, b.angularVelocity);
	}
	releaseHeld(throwIt) {
		const b = this.held;
		if (!b) return;
		b.collisionFilterGroup = 1;
		if (throwIt) {
			this.camera.updateMatrixWorld();
			this.camera.getWorldDirection(this.lookDir);
			b.velocity.x = this.lookDir.x * 18 + this.vx;
			b.velocity.y = this.lookDir.y * 18 + 1.5;
			b.velocity.z = this.lookDir.z * 18 + this.vz;
			this.sfx.play("swing", 1.4, .16);
		}
		b.wakeUp();
		this.held = null;
	}
	pinLook() {
		const hit = this.lookHit(6);
		const dyn = hit?.body ? this.bodyMeta.get(hit.body)?.dyn : void 0;
		if (!dyn || dyn.removed || dyn.kind === "nade") return;
		if (dyn.body.mass > 0) {
			dyn.pinnedMass = dyn.body.mass;
			dyn.body.mass = 0;
			dyn.body.type = Body.STATIC;
			dyn.body.updateMassProperties();
			dyn.body.velocity.set(0, 0, 0);
			dyn.body.angularVelocity.set(0, 0, 0);
			this.hint = "Заморожено";
		} else {
			dyn.body.mass = dyn.pinnedMass || 5;
			dyn.body.type = Body.DYNAMIC;
			dyn.body.updateMassProperties();
			dyn.body.wakeUp();
			this.hint = "Отпущено";
		}
		this.hintT = .9;
	}
	deleteLook() {
		const hit = this.lookHit(7);
		const dyn = hit?.body ? this.bodyMeta.get(hit.body)?.dyn : void 0;
		if (!dyn) return;
		this.removeDyn(dyn);
		this.hint = "Удалено";
		this.hintT = .7;
	}
	lookHit(range) {
		this.camera.updateMatrixWorld();
		this.camera.getWorldDirection(this.lookDir);
		const o = this.camera.position;
		return this.ray(o.x, o.y, o.z, o.x + this.lookDir.x * range, o.y + this.lookDir.y * range, o.z + this.lookDir.z * range);
	}
	tryUse() {
		if (!this.playing || this.paused || this.downT > 0) return;
		if (this.held) {
			this.releaseHeld(true);
			return;
		}
		if (this.driving || this.nearCar()) {
			this.toggleCar();
			return;
		}
		this.melee();
	}
	nearCar() {
		if (this.car.deadT > 0) return false;
		return Math.hypot(this.px - this.car.x, this.pz - this.car.z) < 3.5;
	}
	toggleCar() {
		if (this.driving) {
			this.driving = false;
			const rx = Math.cos(this.car.yaw);
			const rz = -Math.sin(this.car.yaw);
			this.px = this.car.x + rx * 2.2;
			this.pz = this.car.z + rz * 2.2;
			this.py = EYE;
			this.vx = 0;
			this.vz = 0;
			this.vy = 0;
			this.hint = "Пешком";
		} else if (this.car.deadT <= 0) {
			this.driving = true;
			this.wasDriving = false;
			if (this.held) this.releaseHeld(false);
			this.hint = "За рулём";
		}
		this.hintT = 1;
		this.emitNow();
	}
	startReload() {
		const w = WEAPON_SLOTS[this.weapon];
		if (w.kind !== "gun" || this.reloading > 0) return;
		if ((this.mag[this.weapon] ?? 0) >= w.mag) return;
		if (this.mode === "arena" && (this.reserve[this.weapon] ?? 0) <= 0) {
			this.sfx.tone(120, .04, .04, "square");
			return;
		}
		this.reloading = w.reload;
	}
	finishReload() {
		const w = WEAPON_SLOTS[this.weapon];
		if (w.kind !== "gun") return;
		if (this.mode === "sandbox") {
			this.mag[this.weapon] = w.mag;
			return;
		}
		const need = w.mag - (this.mag[this.weapon] ?? 0);
		const take = Math.min(need, this.reserve[this.weapon] ?? 0);
		this.mag[this.weapon] = (this.mag[this.weapon] ?? 0) + take;
		this.reserve[this.weapon] = (this.reserve[this.weapon] ?? 0) - take;
	}
	ray(x1, y1, z1, x2, y2, z2) {
		this.rayFrom.set(x1, y1, z1);
		this.rayTo.set(x2, y2, z2);
		this.rayResult.reset();
		if (!this.world.raycastClosest(this.rayFrom, this.rayTo, {
			skipBackfaces: false,
			collisionFilterMask: 1
		}, this.rayResult) || !this.rayResult.hasHit || !this.rayResult.body) return null;
		const p = this.rayResult.hitPointWorld;
		return {
			x: p.x,
			y: p.y,
			z: p.z,
			distance: this.rayResult.distance,
			body: this.rayResult.body
		};
	}
	los(x1, y1, z1, x2, y2, z2) {
		const hit = this.ray(x1, y1, z1, x2, y2, z2);
		if (!hit) return true;
		return hit.distance > Math.hypot(x2 - x1, y2 - y1, z2 - z1) - .8;
	}
	impulse(body, dx, dy, dz, force, hx, hy, hz) {
		if (body.type !== Body.DYNAMIC || body.mass <= 0) return;
		body.wakeUp();
		this.imp.set(dx * force, dy * force, dz * force);
		this.rel.set(hx - body.position.x, hy - body.position.y, hz - body.position.z);
		body.applyImpulse(this.imp, this.rel);
	}
	damageDyn(d, amount, dir, force, hx, hy, hz, fromBlast) {
		if (d.removed || d.dead) return;
		const dx = dir.x;
		const dy = dir.y;
		const dz = dir.z;
		if (!fromBlast && force > 0) this.impulse(d.body, dx, dy, dz, force, hx, hy, hz);
		d.hp -= amount;
		this.chaos += 1;
		if (d.hp > 0) {
			if (d.kind === "limb" && amount > 30) this.detach(d);
			return;
		}
		const x = d.body.position.x;
		const y = d.body.position.y;
		const z = d.body.position.z;
		if (d.kind === "explosive" || d.kind === "nade") {
			this.removeDyn(d);
			this.explode(x, y, z, d.kind === "nade" ? 16 : 24);
			return;
		}
		if (d.kind === "limb") {
			d.hp = 240;
			this.detach(d);
			return;
		}
		if (d.kind === "crate" || d.kind === "barrel") {
			this.removeDyn(d);
			this.shatter(x, y, z, dx, dy, dz);
			return;
		}
		this.removeDyn(d);
	}
	shatter(x, y, z, dx, dy, dz) {
		this.burst(x, y, z, "#f3eadf", 10, 4);
		this.sfx.play("thud", .6, .25);
		for (let i = 0; i < 3; i++) this.makeDyn({
			kind: "chip",
			x: x + (Math.random() - .5) * .4,
			y: y + .2,
			z: z + (Math.random() - .5) * .4,
			w: .28,
			h: .22,
			d: .26,
			mass: .6,
			color: "#8a5a32",
			hp: 12
		}).body.velocity.set(dx * 4 + (Math.random() - .5) * 3, 2 + Math.random() * 2, dz * 4 + (Math.random() - .5) * 3);
		this.chaos += 8;
		this.trim();
	}
	explode(x, y, z, power) {
		this.sfx.play("boom", .75 + Math.random() * .35, .62);
		this.sfx.tone(48, .28, .16, "sine");
		this.shake = Math.min(1, this.shake + .8);
		this.hitStop = .05;
		this.chaos += 18;
		this.burst(x, y, z, "#e25b1a", 22, 10);
		this.burst(x, y + .4, z, "#f3eadf", 8, 6);
		const radius = 7.6;
		for (const d of this.dyns.slice()) {
			if (d.removed) continue;
			const dx = d.body.position.x - x;
			const dy = d.body.position.y - y;
			const dz = d.body.position.z - z;
			const dist = Math.hypot(dx, dy, dz) || .001;
			if (dist > radius) continue;
			const fall = 1 - dist / radius;
			this.aim.set(dx / dist, dy / dist + .35, dz / dist);
			this.impulse(d.body, this.aim.x, this.aim.y, this.aim.z, power * fall, d.body.position.x, d.body.position.y, d.body.position.z);
			this.damageDyn(d, 18 + power * fall * .7, this.aim, 0, d.body.position.x, d.body.position.y, d.body.position.z, true);
		}
		for (const b of this.bots.slice()) {
			const dist = Math.hypot(b.x - x, 1.1 - y, b.z - z);
			if (dist > radius) continue;
			const fall = 1 - dist / radius;
			this.hurtBot(b, 28 + fall * 55, (b.x - x) / (dist || 1), .45, (b.z - z) / (dist || 1), 7 + fall * 6);
		}
		if (this.playing && this.downT <= 0) {
			const px = this.driving ? this.car.x : this.px;
			const pz = this.driving ? this.car.z : this.pz;
			const dist = Math.hypot(px - x, pz - z);
			if (dist < radius) this.hurtPlayer((1 - dist / radius) * 58);
		}
		if (this.car.deadT <= 0) {
			const dist = Math.hypot(this.car.x - x, this.car.z - z);
			if (dist < radius) {
				const fall = 1 - dist / radius;
				this.car.speed += (this.car.x - x) / (dist || 1) * power * fall * .35;
				this.hurtCar(fall * 48);
			}
		}
		this.saveBest();
	}
	hurtPlayer(amount) {
		this.hurt = 1;
		this.sinceHurt = 0;
		this.shake = Math.min(1, this.shake + .4);
		if (this.mode === "sandbox") {
			this.hp = Math.max(30, this.hp - amount * .22);
			return;
		}
		if (this.invuln > 0 || this.downT > 0) return;
		this.hp -= amount;
		if (this.hp <= 0) {
			this.hp = 0;
			this.downT = 1.7;
			this.driving = false;
			this.hint = "Тебя размазало";
			this.hintT = 1.4;
			this.sfx.play("thud", .55, .4);
		}
	}
	hurtCar(amount) {
		if (this.car.deadT > 0 || this.car.hp <= 0) return;
		this.car.hp -= amount;
		if (this.car.hp > 0) return;
		this.car.hp = 0;
		const x = this.car.x;
		const z = this.car.z;
		this.driving = false;
		this.car.deadT = 3.4;
		this.car.speed = 0;
		this.hint = "Тачка вспыхнула";
		this.hintT = 1.4;
		this.explode(x, .7, z, 18);
	}
	decayCar(dt) {
		if (this.car.deadT <= 0) return;
		this.car.deadT -= dt;
		if (this.car.deadT > 0) return;
		this.car.deadT = 0;
		this.car.hp = 140;
		this.car.x = 6;
		this.car.z = 11;
		this.car.yaw = 0;
		this.car.speed = 0;
	}
	respawn() {
		this.px = 0;
		this.py = EYE;
		this.pz = 18;
		this.vx = 0;
		this.vy = 0;
		this.vz = 0;
		this.hp = 100;
		this.invuln = 1.6;
		this.sinceHurt = 0;
		this.driving = false;
		this.hint = "Снова в деле";
		this.hintT = 1.3;
	}
	updateBots(dt) {
		const tx = this.driving ? this.car.x : this.px;
		const tz = this.driving ? this.car.z : this.pz;
		const ty = this.driving ? 1.1 : this.py * .5 + .8;
		for (const bot of this.bots) {
			bot.cool -= dt;
			const dx = tx - bot.x;
			const dz = tz - bot.z;
			const dist = Math.hypot(dx, dz) || .001;
			let throttle = .75;
			if (bot.hostile && this.playing && dist < 32) {
				const desired = Math.atan2(-dx, -dz);
				const diff = Math.atan2(Math.sin(desired - bot.yaw), Math.cos(desired - bot.yaw));
				bot.yaw += clamp(diff, -2.6 * dt, 2.6 * dt);
				if (dist < 7) throttle = -.35;
				else if (dist < 12) throttle = .2;
				if (this.los(bot.x, 1.45, bot.z, tx, ty, tz) && this.downT <= 0 && dist < 26 && dist > 3 && bot.cool <= 0) {
					bot.cool = .95;
					this.botShoot(bot, tx, ty, tz);
				}
			} else {
				bot.wander -= dt;
				if (bot.wander <= 0) {
					bot.wander = 1.4 + Math.random() * 2.2;
					bot.yaw += (Math.random() - .5) * 2.2;
				}
			}
			const fx = -Math.sin(bot.yaw);
			const fz = -Math.cos(bot.yaw);
			const ox = bot.x;
			const oz = bot.z;
			bot.x += fx * 3.3 * throttle * dt;
			bot.z += fz * 3.3 * throttle * dt;
			const sep = this.separate(bot.x, bot.z, .42, 0, 1.7, false, false);
			if (Math.hypot(sep.x - bot.x, sep.z - bot.z) > .02) bot.yaw += 2.2 * dt;
			bot.x = clamp(sep.x, -33, 33);
			bot.z = clamp(sep.z, -33, 33);
			for (const o of this.bots) {
				if (o === bot) continue;
				const ddx = bot.x - o.x;
				const ddz = bot.z - o.z;
				const d = Math.hypot(ddx, ddz);
				if (d < 1.05 && d > .001) {
					bot.x += ddx / d * (1.05 - d);
					bot.z += ddz / d * (1.05 - d);
				}
			}
			bot.body.position.set(bot.x, 1.05, bot.z);
			bot.mesh.position.set(bot.x, 0, bot.z);
			bot.mesh.rotation.y = bot.yaw;
			const moved = Math.hypot(bot.x - ox, bot.z - oz);
			const swing = Math.sin(this.time * 9 + bot.id) * (moved > .001 ? .7 : 0);
			bot.legL.rotation.x = swing;
			bot.legR.rotation.x = -swing;
			if (bot.flash > 0) {
				bot.flash -= dt;
				bot.mat.emissiveIntensity = bot.flash > 0 ? .9 : 0;
			}
		}
	}
	botShoot(bot, tx, ty, tz) {
		const ox = bot.x;
		const oy = 1.45;
		const oz = bot.z;
		let dx = tx - ox + (Math.random() - .5) * .8;
		let dy = ty - oy + (Math.random() - .5) * .45;
		let dz = tz - oz + (Math.random() - .5) * .8;
		const len = Math.hypot(dx, dy, dz) || 1;
		dx /= len;
		dy /= len;
		dz /= len;
		const hit = this.ray(ox, oy, oz, ox + dx * 40, oy + dy * 40, oz + dz * 40);
		this.tracer(ox, oy, oz, hit ? hit.x : ox + dx * 24, hit ? hit.y : oy + dy * 24, hit ? hit.z : oz + dz * 24);
		this.sfx.play("shot", 1.35, .1);
		if (hit?.body) {
			const meta = this.bodyMeta.get(hit.body);
			if (meta?.dyn) this.damageDyn(meta.dyn, 10, this.aim.set(dx, dy, dz), 2, hit.x, hit.y, hit.z, false);
			if (meta?.bot && meta.bot !== bot) this.hurtBot(meta.bot, 12, dx, dy, dz, 2);
		}
		const px = this.driving ? this.car.x : this.px;
		const py = this.driving ? 1.1 : this.py;
		const pz = this.driving ? this.car.z : this.pz;
		const vx = px - ox;
		const vy = py - oy;
		const vz = pz - oz;
		const t = clamp(vx * dx + vy * dy + vz * dz, 0, 40);
		if (Math.hypot(px - (ox + dx * t), py - (oy + dy * t), pz - (oz + dz * t)) < .72 && (!hit || hit.distance > t - .5)) this.hurtPlayer(8);
	}
	updateWaves(dt) {
		if (!this.playing || this.mode !== "arena" || this.downT > 0) return;
		if (this.waveDelay > 0) {
			this.waveDelay -= dt;
			return;
		}
		if (this.waveLeft > 0 && this.bots.length < 4) {
			this.spawnTimer -= dt;
			if (this.spawnTimer <= 0) {
				this.spawnTimer = .65;
				const edge = Math.floor(Math.random() * 4);
				const a = (Math.random() - .5) * 20;
				const x = edge === 2 ? -28 : edge === 3 ? 28 : a;
				const z = edge === 0 ? -28 : edge === 1 ? 28 : a;
				this.spawnBot(x, z, true);
				this.waveLeft--;
			}
		} else if (this.waveLeft <= 0 && this.bots.length === 0) {
			this.wave++;
			this.waveLeft = Math.min(10, 2 + this.wave);
			this.waveDelay = 2.3;
			this.hint = `Волна ${this.wave}`;
			this.hintT = 1.8;
			this.saveBest();
		}
	}
	updateNades(dt) {
		const due = [];
		for (const d of this.dyns) {
			if (d.kind !== "nade" || d.removed) continue;
			d.fuse -= dt;
			if (d.fuse <= 0) due.push(d);
		}
		for (const d of due) {
			if (d.removed) continue;
			const x = d.body.position.x;
			const y = d.body.position.y;
			const z = d.body.position.z;
			this.removeDyn(d);
			this.explode(x, y, z, 16);
		}
	}
	hurtBot(bot, dmg, dx, dy, dz, force) {
		if (bot.hp <= 0) return;
		bot.hp -= dmg;
		bot.flash = .09;
		bot.mat.emissive.set("#ffffff");
		this.chaos += 2;
		this.hitMark = 1;
		if (bot.hp > 0) return;
		const x = bot.x;
		const z = bot.z;
		this.removeBot(bot);
		this.ragdoll(x, z, dx, dz, 3.5 + force);
		this.kills++;
		this.chaos += 22;
		this.hitStop = .045;
		this.hint = "Рэгдолл";
		this.hintT = .8;
		if (this.mode === "arena") {
			this.reserve[0] = Math.min(120, (this.reserve[0] ?? 0) + 8);
			this.reserve[1] = Math.min(48, (this.reserve[1] ?? 0) + 2);
			this.reserve[2] = Math.min(180, (this.reserve[2] ?? 0) + 12);
		}
		this.sfx.play("thud", .5, .3);
	}
	ragdoll(x, z, dx, dz, power) {
		const len = Math.hypot(dx, dz) || 1;
		const ux = dx / len;
		const uz = dz / len;
		const specs = [
			{
				id: "pelvis",
				px: 0,
				py: .92,
				w: .34,
				h: .22,
				d: .2,
				m: 5,
				color: "#c4551a"
			},
			{
				id: "chest",
				px: 0,
				py: 1.28,
				w: .4,
				h: .34,
				d: .22,
				m: 6,
				color: "#b4532a"
			},
			{
				id: "head",
				px: 0,
				py: 1.68,
				w: .26,
				h: .26,
				d: .26,
				m: 1.8,
				color: "#e7e1d6",
				sphere: true
			},
			{
				id: "armL",
				px: -.36,
				py: 1.26,
				w: .12,
				h: .4,
				d: .12,
				m: 1.1,
				color: "#a84822"
			},
			{
				id: "armR",
				px: .36,
				py: 1.26,
				w: .12,
				h: .4,
				d: .12,
				m: 1.1,
				color: "#a84822"
			},
			{
				id: "legL",
				px: -.1,
				py: .46,
				w: .13,
				h: .5,
				d: .13,
				m: 2,
				color: "#3d342c"
			},
			{
				id: "legR",
				px: .1,
				py: .46,
				w: .13,
				h: .5,
				d: .13,
				m: 2,
				color: "#3d342c"
			}
		];
		const made = /* @__PURE__ */ new Map();
		for (const s of specs) {
			const dyn = this.makeDyn({
				kind: "limb",
				x: x + s.px,
				y: s.py,
				z,
				w: s.w,
				h: s.h,
				d: s.d,
				mass: s.m,
				color: s.color,
				hp: 40,
				sphere: s.sphere
			});
			dyn.body.velocity.set(ux * power, 1.4 + Math.random(), uz * power);
			dyn.body.angularVelocity.set((Math.random() - .5) * 4, (Math.random() - .5) * 4, (Math.random() - .5) * 4);
			made.set(s.id, dyn);
		}
		const link = (a, b) => {
			if (!a || !b) return;
			const mx = (a.body.position.x + b.body.position.x) / 2;
			const my = (a.body.position.y + b.body.position.y) / 2;
			const mz = (a.body.position.z + b.body.position.z) / 2;
			const c = new PointToPointConstraint(a.body, new Vec3(mx - a.body.position.x, my - a.body.position.y, mz - a.body.position.z), b.body, new Vec3(mx - b.body.position.x, my - b.body.position.y, mz - b.body.position.z));
			this.world.addConstraint(c);
			a.links.push(c);
			b.links.push(c);
		};
		link(made.get("pelvis"), made.get("chest"));
		link(made.get("chest"), made.get("head"));
		link(made.get("chest"), made.get("armL"));
		link(made.get("chest"), made.get("armR"));
		link(made.get("pelvis"), made.get("legL"));
		link(made.get("pelvis"), made.get("legR"));
		this.trim();
	}
	detach(d) {
		for (const c of d.links.splice(0)) {
			this.world.removeConstraint(c);
			for (const o of this.dyns) {
				const k = o.links.indexOf(c);
				if (k >= 0) o.links.splice(k, 1);
			}
		}
	}
	updateFx(dt) {
		this.hitMark = Math.max(0, this.hitMark - dt * 6);
		this.hurt = Math.max(0, this.hurt - dt * 1.5);
		this.shake *= Math.exp(-3.4 * dt);
		this.kick *= Math.exp(-8 * dt);
		this.gunKick *= Math.exp(-10 * dt);
		this.bloom = Math.max(0, this.bloom - dt * 1.4);
		this.muzzleT = Math.max(0, this.muzzleT - dt);
		if (this.muzzleMesh) this.muzzleMesh.visible = this.muzzleT > 0;
		for (let i = 0; i < this.sparkLife.length; i++) {
			if (this.sparkLife[i] <= 0) continue;
			this.sparkLife[i] -= dt;
			this.sparkVel[i * 3 + 1] -= 14 * dt;
			this.sparkPos[i * 3] += this.sparkVel[i * 3] * dt;
			this.sparkPos[i * 3 + 1] += this.sparkVel[i * 3 + 1] * dt;
			this.sparkPos[i * 3 + 2] += this.sparkVel[i * 3 + 2] * dt;
			const s = Math.max(0, this.sparkLife[i]);
			this.sparkDummy.position.set(this.sparkPos[i * 3], this.sparkPos[i * 3 + 1], this.sparkPos[i * 3 + 2]);
			this.sparkDummy.scale.setScalar(s * 1.6);
			this.sparkDummy.updateMatrix();
			this.sparkMesh.setMatrixAt(i, this.sparkDummy.matrix);
		}
		this.sparkMesh.instanceMatrix.needsUpdate = true;
		for (const t of this.tracers) {
			if (t.life <= 0) continue;
			t.life -= dt;
			t.mesh.visible = t.life > 0;
		}
	}
	burst(x, y, z, hex, n, speed) {
		this.sparkColor.set(hex);
		for (let k = 0; k < n; k++) {
			const i = this.sparkCursor % this.sparkLife.length;
			this.sparkCursor++;
			this.sparkLife[i] = .28 + Math.random() * .35;
			this.sparkPos[i * 3] = x;
			this.sparkPos[i * 3 + 1] = y;
			this.sparkPos[i * 3 + 2] = z;
			this.sparkVel[i * 3] = (Math.random() - .5) * speed;
			this.sparkVel[i * 3 + 1] = Math.random() * speed * .8;
			this.sparkVel[i * 3 + 2] = (Math.random() - .5) * speed;
			this.sparkMesh.setColorAt(i, this.sparkColor);
		}
		if (this.sparkMesh.instanceColor) this.sparkMesh.instanceColor.needsUpdate = true;
	}
	tracer(x1, y1, z1, x2, y2, z2) {
		const t = this.tracers[this.tracerCursor % this.tracers.length];
		if (!t) return;
		this.tracerCursor++;
		const dx = x2 - x1;
		const dy = y2 - y1;
		const dz = z2 - z1;
		const len = Math.hypot(dx, dy, dz) || .001;
		t.life = .07;
		t.mesh.visible = true;
		t.mesh.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2);
		t.mesh.scale.set(.03, .03, len);
		t.mesh.lookAt(x2, y2, z2);
	}
	syncMeshes() {
		for (const d of this.dyns) {
			d.mesh.position.set(d.body.position.x, d.body.position.y, d.body.position.z);
			d.mesh.quaternion.set(d.body.quaternion.x, d.body.quaternion.y, d.body.quaternion.z, d.body.quaternion.w);
		}
		this.carMesh.visible = this.car.deadT <= 0;
		if (this.car.deadT <= 0) {
			this.carMesh.position.set(this.car.x, 0, this.car.z);
			this.carMesh.rotation.set(0, this.car.yaw, 0);
			for (const w of this.wheels) {
				w.rotation.order = "YXZ";
				w.rotation.y = this.wheelSpin;
			}
		}
	}
	updateCamera(dt) {
		if (!this.playing) {
			this.orbit += dt * (this.reduced ? .04 : .18);
			this.camera.position.set(Math.sin(this.orbit) * 20, 7.6, Math.cos(this.orbit) * 20);
			this.camera.lookAt(0, 1.1, 2);
			this.gun.visible = false;
			this.sky.position.copy(this.camera.position);
			return;
		}
		this.gun.visible = !this.driving && this.downT <= 0;
		if (this.driving && this.car.deadT <= 0) {
			const fx = -Math.sin(this.car.yaw);
			const fz = -Math.cos(this.car.yaw);
			const destX = this.car.x - fx * 6.8;
			const destY = 3.05;
			const destZ = this.car.z - fz * 6.8;
			if (!this.wasDriving) {
				this.camX = destX;
				this.camY = destY;
				this.camZ = destZ;
			}
			const k = 1 - Math.exp(-5 * dt);
			this.camX += (destX - this.camX) * k;
			this.camY += (destY - this.camY) * k;
			this.camZ += (destZ - this.camZ) * k;
			this.camera.position.set(this.camX, this.camY, this.camZ);
			this.camera.lookAt(this.car.x + fx * 3, .85, this.car.z + fz * 3);
			this.wasDriving = true;
		} else {
			this.wasDriving = false;
			const bob = Math.sin(this.walk * 2.1) * Math.min(.045, Math.hypot(this.vx, this.vz) * .006);
			const s = this.shake;
			this.camera.position.set(this.px + (Math.random() - .5) * s * .14, this.py + bob + (Math.random() - .5) * s * .08, this.pz + (Math.random() - .5) * s * .14);
			this.camera.rotation.order = "YXZ";
			this.camera.rotation.set(this.pitch + this.kick, this.yaw, 0);
		}
		const fov = this.ads ? 52 : this.boosting && this.driving ? 86 : 76;
		this.camera.fov += (fov - this.camera.fov) * Math.min(1, 12 * dt);
		this.camera.updateProjectionMatrix();
		this.camera.updateMatrixWorld();
		this.placeGun();
		this.sky.position.copy(this.camera.position);
		this.flash.intensity = this.lampOn ? 18 : 0;
	}
	placeGun() {
		if (!this.gun.visible) return;
		const ads = this.ads ? 1 : 0;
		this.gun.position.copy(this.camera.position);
		this.gun.quaternion.copy(this.camera.quaternion);
		this.gun.translateX(.22 * (1 - ads) + this.sway);
		this.gun.translateY(-.2 + ads * .05 + Math.sin(this.walk * 2.1) * .01);
		this.gun.translateZ(-.48 + this.gunKick);
	}
	render() {
		if (!this.renderer || this.canvas.clientWidth < 2) return;
		this.renderer.autoClear = true;
		this.renderer.render(this.scene, this.camera);
		if (!this.gun.visible) return;
		this.viewCam.position.copy(this.camera.position);
		this.viewCam.quaternion.copy(this.camera.quaternion);
		this.viewCam.fov = this.camera.fov;
		this.viewCam.updateProjectionMatrix();
		this.renderer.autoClear = false;
		this.renderer.clearDepth();
		this.renderer.render(this.scene, this.viewCam);
		this.renderer.autoClear = true;
	}
	resize() {
		const w = this.canvas.clientWidth || window.innerWidth;
		const h = this.canvas.clientHeight || window.innerHeight;
		if (w < 2 || h < 2) return;
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / h;
		this.camera.updateProjectionMatrix();
		this.viewCam.aspect = w / h;
		this.viewCam.updateProjectionMatrix();
	}
	buildLights() {
		this.hemi = new HemisphereLight("#f0a06a", "#2a211c", .62);
		this.hemi.layers.enable(1);
		this.scene.add(this.hemi);
		const amb = new AmbientLight("#f3eadf", .18);
		amb.layers.enable(1);
		this.scene.add(amb);
		this.sun = new DirectionalLight("#ffb067", 1.75);
		this.sun.position.set(48, 16, 18);
		this.sun.layers.enable(1);
		this.scene.add(this.sun);
		this.flash = new SpotLight("#ffe6c4", 0, 22, .62, .45, 1.2);
		this.flash.position.set(.15, -.05, 0);
		this.flash.target.position.set(0, 0, -1);
		this.camera.add(this.flash);
		this.camera.add(this.flash.target);
		this.sunMesh = new Mesh(this.sphereGeo, new MeshBasicMaterial({ color: "#ffb067" }));
		this.sunMesh.scale.setScalar(5);
		this.scene.add(this.sunMesh);
		const canvas = document.createElement("canvas");
		canvas.width = 4;
		canvas.height = 256;
		this.skyCtx = canvas.getContext("2d");
		this.skyTex = new CanvasTexture(canvas);
		this.skyTex.colorSpace = SRGBColorSpace;
		this.skyTex.magFilter = LinearFilter;
		const skyMat = new MeshBasicMaterial({
			map: this.skyTex,
			side: 1,
			depthWrite: false
		});
		this.sky = new Mesh(new SphereGeometry(180, 20, 14), skyMat);
		this.sky.frustumCulled = false;
		this.scene.add(this.sky);
		this.fog = new Fog("#c47a52", 22, 92);
		this.scene.fog = this.fog;
	}
	applyTime() {
		const t = TIMES[this.timeName];
		const g = this.skyCtx;
		const grd = g.createLinearGradient(0, 0, 0, 256);
		grd.addColorStop(0, t.top);
		grd.addColorStop(.55, t.mid);
		grd.addColorStop(1, t.fog);
		g.fillStyle = grd;
		g.fillRect(0, 0, 4, 256);
		this.skyTex.needsUpdate = true;
		this.fog.color.set(t.fog);
		this.sun.color.set(t.sun);
		this.sun.intensity = t.sunI;
		this.sun.position.set(t.sx, t.sy, t.sz);
		this.hemi.color.set(t.hemi);
		this.hemi.groundColor.set(t.ground);
		this.hemi.intensity = t.hemiI;
		this.renderer.toneMappingExposure = t.exp;
		this.sunMesh.material.color.set(t.sun);
		const len = Math.hypot(t.sx, t.sy, t.sz) || 1;
		this.sunMesh.position.set(t.sx / len * 90, t.sy / len * 70, t.sz / len * 90);
		this.flash.intensity = this.lampOn ? 18 : 0;
	}
	buildMap() {
		const tex = this.groundTex();
		const gmat = new MeshLambertMaterial({ map: tex });
		const ground = new Mesh(new PlaneGeometry(96, 96), gmat);
		ground.rotation.x = -Math.PI / 2;
		this.scene.add(ground);
		this.addStatic(0, 2.2, -38, 80, 4.4, 1.2, "#3a342e");
		this.addStatic(0, 2.2, 38, 80, 4.4, 1.2, "#3a342e");
		this.addStatic(-38, 2.2, 0, 1.2, 4.4, 80, "#3a342e");
		this.addStatic(38, 2.2, 0, 1.2, 4.4, 80, "#3a342e");
		this.addStatic(-14, 1.35, -8, 6.6, 2.7, 2.5, "#b4532a");
		this.addStripe(-14, 1.7, -6.66, 6.2, .28, .08);
		this.addStatic(12, 1.35, -16, 2.5, 2.7, 7.2, "#3d4550");
		this.addStripe(13.16, 1.55, -16, .08, .36, 6.6);
		this.addStatic(-22, 1.25, 8, 2.4, 2.5, 6.4, "#6e675f");
		this.addStatic(20, 2.45, -6, 5.2, .28, 5.2, "#5c564e");
		for (let i = 0; i < 7; i++) {
			const h = .36 * (i + 1);
			this.addStatic(13.4 + i * .78, h / 2, -6, .78, h, 2.3, i % 2 ? "#5c564e" : "#6a6158");
		}
		this.addStatic(-3.2, .55, 9.5, 2.4, 1.1, .45, "#6e675f");
		this.addStatic(7.5, .45, 16, 1.6, .9, .4, "#6e675f");
		this.addStatic(-16, .4, 16, 2.2, .8, .5, "#5c564e");
		this.addPole(-8, 10);
		this.addPole(14, 8);
		this.addPole(-6, -12);
		for (const [x, z, s] of [
			[
				-48,
				-28,
				16
			],
			[
				46,
				-20,
				14
			],
			[
				-40,
				30,
				12
			],
			[
				36,
				34,
				18
			]
		]) {
			const hill = new Mesh(this.sphereGeo, this.mat("#241c18"));
			hill.scale.set(s, s * .38, s);
			hill.position.set(x, -1.5, z);
			this.scene.add(hill);
		}
		this.makeSign();
	}
	groundTex() {
		const c = document.createElement("canvas");
		c.width = 512;
		c.height = 512;
		const g = c.getContext("2d");
		g.fillStyle = "#1a1816";
		g.fillRect(0, 0, 512, 512);
		g.strokeStyle = "#2c2824";
		g.lineWidth = 2;
		for (let i = 0; i <= 512; i += 64) {
			g.beginPath();
			g.moveTo(i, 0);
			g.lineTo(i, 512);
			g.stroke();
			g.beginPath();
			g.moveTo(0, i);
			g.lineTo(512, i);
			g.stroke();
		}
		g.strokeStyle = "#e25b1a";
		g.lineWidth = 6;
		g.beginPath();
		g.arc(256, 256, 78, 0, Math.PI * 2);
		g.stroke();
		const tex = new CanvasTexture(c);
		tex.colorSpace = SRGBColorSpace;
		tex.wrapS = RepeatWrapping;
		tex.wrapT = RepeatWrapping;
		tex.repeat.set(8, 8);
		return tex;
	}
	makeSign() {
		const c = document.createElement("canvas");
		c.width = 512;
		c.height = 128;
		const g = c.getContext("2d");
		g.fillStyle = "#1c1814";
		g.fillRect(0, 0, 512, 128);
		g.fillStyle = "#e25b1a";
		g.fillRect(0, 0, 512, 12);
		g.fillRect(0, 116, 512, 12);
		g.fillStyle = "#f3eadf";
		g.font = "700 76px sans-serif";
		g.textAlign = "center";
		g.textBaseline = "middle";
		g.fillText("СВАЛКА", 256, 68);
		const tex = new CanvasTexture(c);
		tex.colorSpace = SRGBColorSpace;
		const mesh = new Mesh(new PlaneGeometry(6.4, 1.6), new MeshBasicMaterial({ map: tex }));
		mesh.position.set(0, 3.4, -22);
		this.scene.add(mesh);
	}
	addPole(x, z) {
		this.addStatic(x, 2.2, z, .16, 4.4, .16, "#2a2420");
		const lamp = new Mesh(this.boxGeo, this.mat("#f3eadf", "#e25b1a"));
		lamp.scale.set(.55, .12, .28);
		lamp.position.set(x, 4.35, z);
		this.scene.add(lamp);
	}
	addStripe(x, y, z, w, h, d) {
		const mesh = new Mesh(this.boxGeo, this.mat("#f3eadf"));
		mesh.scale.set(w, h, d);
		mesh.position.set(x, y, z);
		this.scene.add(mesh);
	}
	addStatic(x, y, z, w, h, d, color) {
		const mesh = new Mesh(this.boxGeo, this.mat(color));
		mesh.scale.set(w, h, d);
		mesh.position.set(x, y, z);
		this.scene.add(mesh);
		const body = new Body({
			mass: 0,
			material: this.groundMat
		});
		body.addShape(new Box$1(new Vec3(w / 2, h / 2, d / 2)));
		body.position.set(x, y, z);
		this.world.addBody(body);
		this.statics.push({
			minX: x - w / 2,
			maxX: x + w / 2,
			minY: y - h / 2,
			maxY: y + h / 2,
			minZ: z - d / 2,
			maxZ: z + d / 2
		});
	}
	mat(color, emissive = "") {
		const key = `${color}|${emissive}`;
		let m = this.mats.get(key);
		if (!m) {
			m = new MeshLambertMaterial({
				color,
				emissive: emissive || "#000000",
				emissiveIntensity: emissive ? .55 : 0
			});
			this.mats.set(key, m);
		}
		return m;
	}
	buildCar() {
		const g = new Group();
		const body = new Mesh(this.boxGeo, this.mat("#8a3a22"));
		body.scale.set(1.55, .42, 2.7);
		body.position.y = .55;
		const cab = new Mesh(this.boxGeo, this.mat("#241c18"));
		cab.scale.set(1.25, .38, 1.15);
		cab.position.set(0, .92, -.15);
		g.add(body, cab);
		for (const [x, y, z] of [
			[
				.72,
				.28,
				.85
			],
			[
				-.72,
				.28,
				.85
			],
			[
				.72,
				.28,
				-.9
			],
			[
				-.72,
				.28,
				-.9
			]
		]) {
			const pivot = new Group();
			pivot.position.set(x, y, z);
			const w = new Mesh(this.cylGeo, this.mat("#141210"));
			w.scale.set(.32, .18, .32);
			w.rotation.z = Math.PI / 2;
			pivot.add(w);
			g.add(pivot);
			this.wheels.push(pivot);
		}
		this.carMesh = g;
		this.scene.add(g);
	}
	dressProps() {
		for (const [x, y, z] of [
			[
				-6,
				.4,
				5
			],
			[
				-5.1,
				.4,
				6.2
			],
			[
				-5.6,
				1.2,
				5.5
			],
			[
				2.2,
				.4,
				-2.5
			],
			[
				9,
				.4,
				5
			]
		]) this.makeDyn({
			kind: "crate",
			x,
			y,
			z,
			w: .8,
			h: .8,
			d: .8,
			mass: 6,
			color: "#8a5a32",
			hp: 40
		});
		this.makeDyn({
			kind: "crate",
			x: .4,
			y: 6.5,
			z: 1.2,
			w: .9,
			h: .9,
			d: .9,
			mass: 8,
			color: "#a36b3c",
			hp: 40
		});
		for (const [x, y, z] of [
			[
				-8,
				.55,
				2
			],
			[
				4.2,
				.55,
				1.5
			],
			[
				-12,
				.55,
				12
			]
		]) this.makeDyn({
			kind: "barrel",
			x,
			y,
			z,
			w: .72,
			h: 1.05,
			d: .72,
			mass: 8,
			color: "#3d4550",
			hp: 55,
			cyl: true
		});
		for (const [x, y, z] of [
			[
				-1.4,
				.55,
				4.4
			],
			[
				.6,
				.55,
				5.2
			],
			[
				1.8,
				.55,
				3.6
			]
		]) this.makeDyn({
			kind: "explosive",
			x,
			y,
			z,
			w: .74,
			h: 1.05,
			d: .74,
			mass: 9,
			color: "#9e1b2d",
			emissive: "#d7263d",
			hp: 22,
			cyl: true
		});
		this.makeDyn({
			kind: "ball",
			x: 11,
			y: 1.2,
			z: 7,
			w: 1.2,
			h: 1,
			d: 1,
			mass: 3.2,
			color: "#e25b1a",
			hp: 90,
			sphere: true,
			bouncy: true
		});
		this.makeDyn({
			kind: "block",
			x: -15,
			y: .45,
			z: 14,
			w: 1.3,
			h: .8,
			d: .7,
			mass: 20,
			color: "#6e675f",
			hp: 130
		});
	}
	dressBots() {
		this.spawnBot(-4, 7, false);
		this.spawnBot(3.5, 1.5, false);
		this.spawnBot(-9, -4, false);
	}
	makeDyn(o) {
		let mesh;
		let shape;
		if (o.sphere) {
			const r = o.w * .5;
			mesh = new Mesh(this.sphereGeo, this.mat(o.color, o.emissive ?? ""));
			mesh.scale.setScalar(r);
			shape = new Sphere(r);
		} else if (o.cyl) {
			const r = o.w * .5;
			mesh = new Mesh(this.cylGeo, this.mat(o.color, o.emissive ?? ""));
			mesh.scale.set(r, o.h, r);
			shape = new Cylinder(r, r, o.h, 10);
		} else {
			mesh = new Mesh(this.boxGeo, this.mat(o.color, o.emissive ?? ""));
			mesh.scale.set(o.w, o.h, o.d);
			shape = new Box$1(new Vec3(o.w / 2, o.h / 2, o.d / 2));
		}
		mesh.position.set(o.x, o.y, o.z);
		this.scene.add(mesh);
		const body = new Body({
			mass: o.mass,
			material: o.bouncy ? this.bouncyMat : this.propMat,
			shape
		});
		body.position.set(o.x, o.y, o.z);
		body.linearDamping = o.kind === "limb" ? .15 : .06;
		body.angularDamping = o.kind === "limb" ? .4 : .08;
		body.allowSleep = o.kind !== "nade";
		this.world.addBody(body);
		const dyn = {
			body,
			mesh,
			kind: o.kind,
			hp: o.hp,
			dead: false,
			removed: false,
			links: [],
			fuse: o.fuse ?? 0,
			pinnedMass: o.mass
		};
		this.dyns.push(dyn);
		this.bodyMeta.set(body, { dyn });
		return dyn;
	}
	spawnBot(x, z, hostile) {
		if (this.bots.length >= 6) return;
		const visual = this.makeBotVisual(hostile);
		visual.g.position.set(x, 0, z);
		this.scene.add(visual.g);
		const body = new Body({
			mass: 0,
			type: Body.KINEMATIC
		});
		body.addShape(new Box$1(new Vec3(.26, .55, .18)));
		body.position.set(x, 1.05, z);
		body.collisionFilterGroup = 1;
		this.world.addBody(body);
		const bot = {
			id: ++this.botSeq,
			x,
			z,
			yaw: Math.random() * Math.PI * 2,
			hp: 100,
			mesh: visual.g,
			mat: visual.mat,
			headMat: visual.headMat,
			legL: visual.legL,
			legR: visual.legR,
			body,
			cool: .5,
			wander: 1,
			flash: 0,
			hostile
		};
		this.bodyMeta.set(body, { bot });
		this.bots.push(bot);
	}
	makeBotVisual(hostile) {
		const mat = new MeshLambertMaterial({
			color: hostile ? "#9e2a2b" : "#c4551a",
			emissive: "#000000"
		});
		const headMat = new MeshLambertMaterial({ color: "#e7e1d6" });
		const g = new Group();
		const torso = new Mesh(this.boxGeo, mat);
		torso.scale.set(.42, .55, .24);
		torso.position.y = 1.2;
		const head = new Mesh(this.sphereGeo, headMat);
		head.scale.setScalar(.16);
		head.position.set(0, 1.62, 0);
		const visor = new Mesh(this.boxGeo, this.mat(hostile ? "#d7263d" : "#1a120e"));
		visor.scale.set(.14, .05, .05);
		visor.position.set(0, 1.62, -.14);
		const legL = new Mesh(this.boxGeo, mat);
		legL.scale.set(.12, .48, .12);
		legL.position.set(-.1, .42, 0);
		const legR = new Mesh(this.boxGeo, mat);
		legR.scale.set(.12, .48, .12);
		legR.position.set(.1, .42, 0);
		const armL = new Mesh(this.boxGeo, mat);
		armL.scale.set(.1, .42, .1);
		armL.position.set(-.3, 1.18, 0);
		const armR = new Mesh(this.boxGeo, mat);
		armR.scale.set(.1, .42, .1);
		armR.position.set(.3, 1.18, 0);
		g.add(torso, head, visor, legL, legR, armL, armR);
		return {
			g,
			mat,
			headMat,
			legL,
			legR
		};
	}
	removeBot(bot) {
		this.world.removeBody(bot.body);
		this.bodyMeta.delete(bot.body);
		this.scene.remove(bot.mesh);
		bot.mat.dispose();
		bot.headMat.dispose();
		const i = this.bots.indexOf(bot);
		if (i >= 0) this.bots.splice(i, 1);
	}
	clearBots() {
		while (this.bots.length) this.removeBot(this.bots[0]);
	}
	removeDyn(d) {
		if (d.removed) return;
		d.removed = true;
		d.dead = true;
		if (this.held === d.body) {
			this.held.collisionFilterGroup = 1;
			this.held = null;
		}
		for (const c of d.links) {
			this.world.removeConstraint(c);
			for (const o of this.dyns) {
				const k = o.links.indexOf(c);
				if (k >= 0) o.links.splice(k, 1);
			}
		}
		d.links.length = 0;
		this.world.removeBody(d.body);
		this.scene.remove(d.mesh);
		this.bodyMeta.delete(d.body);
		const i = this.dyns.indexOf(d);
		if (i >= 0) this.dyns.splice(i, 1);
	}
	clearDynamics() {
		while (this.dyns.length) this.removeDyn(this.dyns[0]);
	}
	trim() {
		if (this.dyns.length <= 54) return;
		const junk = this.dyns.find((d) => d.kind === "chip" || d.kind === "limb");
		if (junk) this.removeDyn(junk);
	}
	rebuildGun() {
		this.gun.clear();
		const kind = WEAPON_SLOTS[this.weapon].kind;
		const steel = this.mat("#8a7568");
		const dark = this.mat("#1c1814");
		const rust = this.mat("#e25b1a");
		const add = (sx, sy, sz, x, y, z, material) => {
			const m = new Mesh(this.boxGeo, material);
			m.scale.set(sx, sy, sz);
			m.position.set(x, y, z);
			this.gun.add(m);
		};
		let tip = -.45;
		if (kind === "gun") {
			const len = this.weapon === 1 ? .78 : this.weapon === 2 ? .9 : .46;
			add(.07, .08, len, 0, 0, -len * .35, steel);
			add(.05, .14, .16, 0, -.1, .02, dark);
			if (this.weapon === 1) add(.09, .07, len * .62, .05, .03, -.28, steel);
			if (this.weapon === 2) add(.04, .16, .2, 0, .02, .16, dark);
			tip = -len * .35 - len * .5;
		} else if (kind === "claw") {
			add(.06, .06, .34, 0, 0, -.16, rust);
			add(.03, .16, .03, 0, .08, -.36, steel);
			add(.16, .03, .03, 0, -.04, -.36, steel);
			tip = -.4;
		} else if (kind === "nade") {
			const s = new Mesh(this.sphereGeo, this.mat("#3d4550"));
			s.scale.setScalar(.09);
			s.position.set(0, -.02, -.18);
			this.gun.add(s);
			tip = -.28;
		} else {
			add(.045, .045, .62, 0, 0, -.28, dark);
			add(.1, .025, .16, 0, .02, -.6, steel);
			tip = -.7;
		}
		this.muzzleMesh = new Mesh(this.sphereGeo, this.muzzleMat);
		this.muzzleMesh.scale.setScalar(.07);
		this.muzzleMesh.position.set(0, .02, tip);
		this.muzzleMesh.visible = false;
		this.gun.add(this.muzzleMesh);
		this.gun.traverse((o) => o.layers.set(1));
		this.gun.frustumCulled = false;
	}
	initFx() {
		const geo = new SphereGeometry(.06, 5, 4);
		const mat = new MeshBasicMaterial({ color: "#ffffff" });
		this.sparkMesh = new InstancedMesh(geo, mat, this.sparkLife.length);
		this.sparkMesh.instanceMatrix.setUsage(DynamicDrawUsage);
		this.sparkMesh.count = this.sparkLife.length;
		for (let i = 0; i < this.sparkLife.length; i++) {
			this.sparkDummy.position.set(0, -30, 0);
			this.sparkDummy.scale.setScalar(0);
			this.sparkDummy.updateMatrix();
			this.sparkMesh.setMatrixAt(i, this.sparkDummy.matrix);
			this.sparkMesh.setColorAt(i, this.sparkColor.set("#ffffff"));
		}
		this.scene.add(this.sparkMesh);
		const tmat = new MeshBasicMaterial({ color: "#ffb067" });
		for (let i = 0; i < 18; i++) {
			const mesh = new Mesh(this.boxGeo, tmat);
			mesh.visible = false;
			mesh.frustumCulled = false;
			this.scene.add(mesh);
			this.tracers.push({
				mesh,
				life: 0
			});
		}
	}
	loadBest() {
		try {
			this.bestWave = Number(localStorage.getItem("svalka.wave") || 0);
			this.bestChaos = Number(localStorage.getItem("svalka.chaos") || 0);
			this.sfx.muted = localStorage.getItem("svalka.mute") === "1";
		} catch {}
	}
	saveBest() {
		try {
			if (this.wave > this.bestWave) {
				this.bestWave = this.wave;
				localStorage.setItem("svalka.wave", String(this.wave));
			}
			if (this.chaos > this.bestChaos) {
				this.bestChaos = Math.floor(this.chaos);
				localStorage.setItem("svalka.chaos", String(this.bestChaos));
			}
		} catch {}
	}
	emitNow() {
		this.onHud?.(this.snapshot());
	}
	snapshot() {
		const w = WEAPON_SLOTS[this.weapon];
		return {
			playing: this.playing,
			paused: this.paused,
			mode: this.mode,
			hp: Math.round(this.hp),
			mag: this.mag[this.weapon] ?? 0,
			reserve: this.reserve[this.weapon] ?? 0,
			weapon: this.weapon,
			weaponName: w.name,
			showAmmo: w.kind === "gun" || w.kind === "nade",
			wave: this.wave,
			kills: this.kills,
			chaos: Math.floor(this.chaos),
			hint: this.hintT > 0 ? this.hint : "",
			hit: this.hitMark > .15,
			hurt: this.hurt,
			driving: this.driving,
			time: this.timeName,
			hostile: this.hostile,
			slow: this.slow,
			grabbed: this.held !== null,
			down: this.downT > 0,
			spread: w.spread + this.bloom * .08,
			bestWave: this.bestWave,
			bestChaos: this.bestChaos,
			muted: this.sfx.muted,
			lamp: this.lampOn,
			carHp: Math.max(0, Math.round(this.car.hp))
		};
	}
};
var EMPTY = {
	playing: false,
	paused: false,
	mode: "sandbox",
	hp: 100,
	mag: 12,
	reserve: 72,
	weapon: 0,
	weaponName: "Пистолет",
	showAmmo: true,
	wave: 1,
	kills: 0,
	chaos: 0,
	hint: "",
	hit: false,
	hurt: 0,
	driving: false,
	time: "dusk",
	hostile: false,
	slow: false,
	grabbed: false,
	down: false,
	spread: .02,
	bestWave: 0,
	bestChaos: 0,
	muted: false,
	lamp: false,
	carHp: 140
};
var SPAWNS = [
	{
		id: "explosive",
		label: "Взрыв",
		icon: Bomb
	},
	{
		id: "barrel",
		label: "Бочка",
		icon: Circle
	},
	{
		id: "crate",
		label: "Ящик",
		icon: Box
	},
	{
		id: "ball",
		label: "Шар",
		icon: Circle
	},
	{
		id: "block",
		label: "Блок",
		icon: Box
	},
	{
		id: "bot",
		label: "Бот",
		icon: User
	}
];
function YardApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const simRef = (0, import_react.useRef)(null);
	const touchRef = (0, import_react.useRef)({
		moveX: 0,
		moveY: 0,
		fire: false,
		jump: false,
		use: false
	});
	const [hud, setHud] = (0, import_react.useState)(EMPTY);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [stick, setStick] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let dead = false;
		let sim = null;
		import("./yard-sim-B1CxYXqg.mjs").then(({ YardSim: Sim }) => {
			if (dead) return;
			try {
				sim = new Sim();
				sim.mount(canvas, setHud, touchRef.current);
				simRef.current = sim;
				setReady(true);
			} catch (err) {
				setError(err instanceof Error ? err.message : "Двор не собрался");
			}
		});
		return () => {
			dead = true;
			sim?.dispose();
			simRef.current = null;
		};
	}, []);
	function start(mode) {
		simRef.current?.unlock();
		simRef.current?.begin(mode);
	}
	const hurt = Math.max(hud.hurt, hud.hp < 32 ? (32 - hud.hp) / 40 : 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "yard relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full",
				"aria-label": "Свалка, трёхмерная песочница"
			}),
			hud.playing && !hud.paused && !hud.driving && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-1/2 top-1/2",
					style: { transform: `translate(-50%, -50%) scale(${1 + Math.min(1.4, hud.spread * 10)})` },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, {
						className: "size-7 text-fg opacity-80",
						strokeWidth: 1.5
					})
				}), hud.hit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/2 top-1/2 size-4 -translate-1/2 rotate-45 border-2 border-accent" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20",
				style: { boxShadow: `inset 0 0 140px rgba(215, 38, 61, ${hurt * .72})` }
			}),
			hud.playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 z-30 flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto min-w-40 rounded-xl border border-border bg-surface px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex items-center justify-between text-xs text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.mode === "arena" ? `Волна ${hud.wave}` : "Песочница" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [hud.kills, " сбито"] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-2 overflow-hidden rounded-full bg-bg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-accent",
										style: { width: `${hud.hp}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-sm tracking-wide",
									children: hud.weaponName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [hud.showAmmo ? `${hud.mag} / ${hud.reserve}` : hud.grabbed ? "Держит" : "—", hud.driving ? ` · тачка ${hud.carHp}` : ""]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pointer-events-auto flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: hud.muted ? "Звук" : "Тише",
								onClick: () => simRef.current?.toggleMute(),
								children: hud.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
								label: "Пауза",
								onClick: () => simRef.current?.togglePause(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
							})]
						})]
					}),
					hud.hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pointer-events-none mx-auto rounded-full border border-border bg-surface px-4 py-1 text-sm",
						children: hud.hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto safe-b flex flex-col gap-2 p-3",
						children: [hud.mode === "sandbox" && !hud.driving && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "scroll-x pointer-events-auto flex gap-2 pb-1",
							children: [
								SPAWNS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm",
									onClick: () => simRef.current?.spawnKind(s.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "size-4 text-primary" }), s.label]
								}, s.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm",
									onClick: () => simRef.current?.toggleHostile(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4 text-accent" }), hud.hostile ? "Злые" : "Мирные"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm",
									onClick: () => simRef.current?.cycleTime(),
									children: [hud.time === "night" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4 text-primary" }), "Время"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm",
									onClick: () => simRef.current?.toggleSlow(),
									children: hud.slow ? "Слоу" : "Темп"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-11 shrink-0 items-center gap-2 rounded-xl border border-border bg-surface px-3 text-sm",
									onClick: () => simRef.current?.clearMess(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Сброс"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-auto flex justify-center gap-1",
							children: WEAPON_SLOTS.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `h-12 min-w-14 rounded-lg px-2 text-xs ${i === hud.weapon ? "bg-primary text-bg" : "border border-border bg-surface text-fg"}`,
								onClick: () => simRef.current?.setWeapon(i),
								children: w.short
							}, w.short))
						})]
					})
				]
			}),
			hud.playing && !hud.paused && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-20 md:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, {
						x: stick.x,
						y: stick.y,
						onChange: (x, y) => {
							touchRef.current.moveX = x;
							touchRef.current.moveY = y;
							setStick({
								x,
								y
							});
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute top-0 right-0 bottom-36 left-1/2",
						onPointerDown: (e) => {
							e.currentTarget.setPointerCapture(e.pointerId);
							e.currentTarget.dataset.x = String(e.clientX);
							e.currentTarget.dataset.y = String(e.clientY);
						},
						onPointerMove: (e) => {
							const el = e.currentTarget;
							if (!el.hasPointerCapture(e.pointerId)) return;
							const lx = Number(el.dataset.x || e.clientX);
							const ly = Number(el.dataset.y || e.clientY);
							simRef.current?.addLook(e.clientX - lx, e.clientY - ly);
							el.dataset.x = String(e.clientX);
							el.dataset.y = String(e.clientY);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute right-3 bottom-36 flex flex-col gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
								label: "Огонь",
								onHold: (v) => touchRef.current.fire = v,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
								label: "Прыжок",
								onHold: (v) => touchRef.current.jump = v,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-sm",
									children: "ПРЫЖ"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hold, {
								label: "Действие",
								onHold: (v) => touchRef.current.use = v,
								children: hud.driving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, { className: "size-6" }) : hud.grabbed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: "size-6" })
							})
						]
					})
				]
			}),
			!hud.playing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "absolute inset-x-0 bottom-0 z-40 max-h-[78%] overflow-auto border-t border-border bg-surface md:inset-y-0 md:right-auto md:w-96 md:max-h-none md:border-t-0 md:border-r",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hazard h-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "safe-b flex flex-col gap-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-[0.22em] text-primary",
							children: "ФИЗИЧЕСКАЯ ПЕСОЧНИЦА"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl leading-none tracking-wide",
							children: "СВАЛКА"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: "Рэгдоллы, клешня, тачка и цепные взрывы. Песочница без правил — или арена, где манекены стреляют в ответ."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Клешня",
									text: "Хватай и швыряй"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Рэгдолл",
									text: "Тело разваливается"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Тачка",
									text: "F, газ и занос"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									title: "Бочки",
									text: "Одна искра — двор"
								})
							]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-accent",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-12 items-center justify-center gap-2 rounded-xl bg-primary font-display tracking-wide text-bg",
							onClick: () => start("sandbox"),
							disabled: !ready,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }), "Песочница"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex h-12 items-center justify-center gap-2 rounded-xl border border-border bg-bg font-display tracking-wide",
							onClick: () => start("arena"),
							disabled: !ready,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "size-5 text-accent" }), "Арена"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-muted",
							children: "ПК: WASD, мышь, ЛКМ, колесо — оружие, F — тачка, E — бросок, C — слоу, N — время. Телефон: стик слева, взгляд справа."
						}),
						(hud.bestChaos > 0 || hud.bestWave > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Рекорд хаоса ",
								hud.bestChaos,
								hud.bestWave > 1 ? ` · волна ${hud.bestWave}` : ""
							]
						}),
						!ready && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Собираем двор…"
						})
					]
				})]
			}),
			hud.paused && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "absolute inset-0 z-40 flex items-end justify-center bg-bg/80 md:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "safe-b w-full max-w-md border border-border bg-surface p-5 md:rounded-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl tracking-wide",
							children: "Пауза"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "WASD — бег" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Мышь — взгляд" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ЛКМ — огонь" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "ПКМ — прицел / лёд" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "F — тачка" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "E — бросок" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1–6 — оружие" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "X — удалить" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-4 flex h-12 w-full items-center justify-center rounded-xl bg-primary font-display text-bg",
							onClick: () => simRef.current?.togglePause(),
							children: "Дальше"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 flex h-12 w-full items-center justify-center rounded-xl border border-border",
							onClick: () => {
								simRef.current?.togglePause();
								start(hud.mode);
							},
							children: "Заново"
						})
					]
				})
			})
		]
	});
}
function Fact({ title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm tracking-wide",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: text
		})]
	});
}
function IconBtn({ label, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "flex size-12 items-center justify-center rounded-xl border border-border bg-surface",
		onClick,
		children
	});
}
function Hold({ label, onHold, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "flex size-14 items-center justify-center rounded-full border border-border bg-surface/90 text-fg",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			onHold(true);
		},
		onPointerUp: () => onHold(false),
		onPointerCancel: () => onHold(false),
		children
	});
}
function Stick({ x, y, onChange }) {
	const ref = (0, import_react.useRef)(null);
	const read = (cx, cy) => {
		const r = ref.current?.getBoundingClientRect();
		if (!r) return;
		let nx = (cx - r.left) / r.width * 2 - 1;
		let ny = -((cy - r.top) / r.height * 2 - 1);
		const len = Math.hypot(nx, ny) || 1;
		const k = Math.min(1, len);
		nx = nx / len * k;
		ny = ny / len * k;
		onChange(nx, ny);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "absolute bottom-36 left-4 size-32 rounded-full border border-border bg-surface/70",
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			read(e.clientX, e.clientY);
		},
		onPointerMove: (e) => {
			if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
			read(e.clientX, e.clientY);
		},
		onPointerUp: () => onChange(0, 0),
		onPointerCancel: () => onChange(0, 0),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute size-12 rounded-full bg-primary",
			style: {
				left: `${50 + x * 28}%`,
				top: `${50 - y * 28}%`,
				transform: "translate(-50%, -50%)"
			}
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(YardApp, {});
}
//#endregion
export { Home as component, YardSim as n, routes_qHReKcwB_exports as r, WEAPON_SLOTS as t };
